import java.util.Scanner;
public class Product {

    public static void main(String[] args) {
        
        Scanner src=new Scanner(System.in);
        int a=src.nextInt();
        int b=src.nextInt();
        System.out.println(a*b);
    }
}