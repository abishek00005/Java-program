import java.util.Scanner;
public class Absolute{

    public static void main(String[] args) {
        
        Scanner src=new Scanner(System.in);
        int a=src.nextInt();
        System.out.println(Math.abs(a));
    }
}