import java.util.Scanner;
public class Cube {

    public static void main(String[] args) {
        
        Scanner src=new Scanner(System.in);
        int a=src.nextInt();
        int n=a*a*a;
        System.out.println(n);
    }
}