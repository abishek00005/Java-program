import java.util.Scanner;
public class Distancetravel {
    
      public static void main(String[] args) {
        Scanner src=new Scanner(System.in);
        int time= src.nextInt();
        int speed= src.nextInt();
        int distance=time*speed;
        System.out.println(distance);

    }

    
}
