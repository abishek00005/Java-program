import java.util.Scanner;
public class Smallest {

    public static void main(String[] args) {
        Scanner src=new Scanner(System.in);
        int a=src.nextInt();
        int b=src.nextInt();
        int c=src.nextInt();
    if(a<b && a<c)
    {
        System.out.println(a+"a is small ");
    }
    else if(b>a && b>c)
        {
            System.out.println(b+"b is small ");
        }
    else
    {
        System.out.println(c+"c is small");
    }       

    }
}
