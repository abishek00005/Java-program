import java.util.Scanner;
public class Areaofsquare {

     public static void main(String[] args) {
        Scanner src=new Scanner(System.in);
        int a=src.nextInt();
        int areaofsquare=a*a;
        System.out.println(areaofsquare);
     }
}