import java.util.Scanner;
public class Circle {
   
     public static void main(String[] args) {
        Scanner src=new Scanner(System.in);
        double r=src.nextDouble();
        double circle=3.14*r*r;
        System.out.println(circle);
     
}
}
