import java.util.Scanner;
public class Q18 {
    public static void main(String[] args) {
        System.out.println(Character.BYTES);
        
    }
}
