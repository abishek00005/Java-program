import java.util.Scanner;
public class Q16 {
    public static void main(String[] args) {
        Scanner src=new Scanner(System.in);
        int date=src.nextInt();
        int  month=src.nextInt();
        int  year=src.nextInt();
        System.out.println(date+"/"+month+"/"+year);
        
    }
}
