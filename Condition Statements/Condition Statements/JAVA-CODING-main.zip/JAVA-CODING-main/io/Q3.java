import java.util.Scanner;
public class Q3
{
    public static void main(String[] agrs)
    {
        Scanner sc=new Scanner(System.in);
        String a =sc.nextLine();
        System.out.println(a);
    }
}