import java.util.Scanner;
public class Q19{
    public static void main(String[] args) {
        Scanner sc=new Scanner(System.in);
        int rollnumber=sc.nextInt();
        sc.nextLine();
        String name=sc.nextLine();
        System.out.println("roll number:"+rollnumber+",name:"+name);
        
    }
}
