import java.util.Scanner;
public class Q2 {
    public static void main(String[]args)
    {
        Scanner sc =new Scanner(System.in);
        System.out.println("enter the word:");
        String a=sc.next(); 
        System.out.println(a);
    }

    
}
